#!/usr/bin/python3
#-*- coding: utf-8 -*-

class Class:
    
    a = 10
    b = 20
    c = 30
    
    def get_value(self, x):
        return x
    
    def get_bool(self, x):
        if x :
            return True
        else :
            return False

