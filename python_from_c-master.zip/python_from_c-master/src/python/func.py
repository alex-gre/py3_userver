#!/usr/bin/python3
#-*- coding: utf-8 -*-

a = 11
b = 22
c = 33

def get_value(x):
    return x


