#!/usr/bin/python3
#-*- coding: utf-8 -*-

def get_value(x):
    return x

